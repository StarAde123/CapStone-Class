//create your variable
var ghost, ghost_moving;
var tower, tower_moving;
var door, door_photo;
var climber, climber_photo;
var doorGroup, climberGroup;
var invisibleBlock, invisibleGroup;
var gameState = "play";
var score=0;

//store your score
localStorage["HighestScore"] = 0;

function preload() {
//preload your images
  ghost_moving = loadImage("ghost-standing.png");
  door_photo = loadImage("door.png");
  climber_photo = loadImage("climber.png");
  tower_moving = loadImage("tower.png");
}

function setup() {
//create the canvas and add your images  
  createCanvas(600, 600);
  tower = createSprite(300, 300, 10, 10);
  tower.addImage("building", tower_moving);
  tower.velocityY = 5;
  
  ghost = createSprite(200, 200, 10, 10);
  ghost.addImage("small_ghost", ghost_moving);
  ghost.scale = 0.3;
//also create your groups  
  doorGroup = new Group();
  climberGroup = new Group();
  invisibleGroup = new Group();
}

function draw() {
//add your background and set up your score
  background("black");
  fill("yellow")
  text("Score: "+ score, 500,50);

//create conditions for your game states
if(gameState === "play") {
//now add points to your score according to your game
score = score + Math.round(getFrameRate()/60);
tower.velocityY = (6 + 3*score/100);

//make sure to add conditions for your images and your ghost
if(tower.y > 600) {
  tower.y = 300;
}
spawnDoors();

if(keyDown("right_arrow")) {
  ghost.x = ghost.x + 5;
}

if(keyDown("left_arrow")) {
  ghost.x = ghost.x - 5;
}
  
if(keyWentDown("space")) {
  ghost.velocityY = -5;
}

  ghost.velocityY = ghost.velocityY + 0.8;
  
if(ghost.isTouching(climberGroup)) {
  ghost.velocityY = 0;
}

if(ghost.isTouching(invisibleGroup)|| (ghost.y > 600)) {
  gameState = "end";
  ghost.destroy();
}
//draw your sprites
  drawSprites();
}
if(gameState === "end") {
  textSize(30);
  text("Game Over", 230, 300);
  }
}
function spawnDoors() {
//create the functions for your images and customize them appropriately to the game
  if(frameCount%250 === 0) {
    door = createSprite(100, -50, 10, 10);
    door.addImage("wall", door_photo);
    door.velocityY = 2;
    door.x = Math.round(random(120, 400))
    
    climber = createSprite(100, 0, 10, 10);
    climber.addImage("climb", climber_photo);
    climber.velocityY = 2;
    climber.x = door.x;
    
    door.lifetime = 360;
    climber.lifetime = 360;
    
    door.depth = ghost.depth;
    ghost.depth = ghost.depth + 1;
    
//add the right sprites to your groups
    climberGroup.add(climber);
    doorGroup.add(door);
    
//finish making your sprites and any other thing needed to be done   
    invisibleBlock = createSprite(100, 25, 10, 10);
    invisibleBlock.width = climber.width;
    invisibleBlock.x = door .x;
    invisibleBlock.height = 2;
    invisibleBlock.velocityY = 2;
    invisibleBlock.visible = false;
    invisibleGroup.add(invisibleBlock);
  }
}